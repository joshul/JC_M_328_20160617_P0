/*****************************************************************************
* Module    : UI
* File      : ui_template.c
* Author    : Hanny
* Function  : UI��ģ���ļ�
*****************************************************************************/
#ifndef CONFIG_C

#pragma location="TASK_TEMPLATE_SEG"
void task_template_deal_msg(u8 msg)
{

}

#pragma location="TASK_TEMPLATE_SEG"
void task_template_display(void)
{

}

#endif
