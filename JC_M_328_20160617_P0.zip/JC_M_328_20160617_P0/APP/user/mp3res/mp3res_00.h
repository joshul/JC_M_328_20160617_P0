#ifndef __MP3RES_H_
#define __MP3RES_H_



#define       RES_WAV_KEY                                                      0x00



#endif 
