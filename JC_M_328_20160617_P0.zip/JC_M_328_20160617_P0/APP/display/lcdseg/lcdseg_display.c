/*****************************************************************************
 * Module    : Display
 * File      : lcdseg_display.h
 * Author    : Hanny
 * Function  : LCD��������ʾ����
*****************************************************************************/
#include "include.h"
#if IS_LCDSEG_DISPLAY

//�ȴ�����
#pragma location="DRAW_IMG_SEG1"
void draw_wait(void)
{
}

//����
void draw_clear(void)
{
}


#endif
